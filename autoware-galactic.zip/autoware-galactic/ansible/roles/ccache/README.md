# ccache

This role installs Ccache. You can access detailed information about Ccache with this [link](https://ccache.dev/).

## Inputs

None.

## Manual Installation

```bash
sudo apt update && sudo apt install ccache
```
