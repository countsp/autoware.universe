# Git Large File Storage

This role installs Git LFS. You can access detailed information about Git LFS with [this link](https://git-lfs.github.com/).

## Inputs

None.

## Manual Installation

```bash
sudo apt install git-lfs
git lfs install
```
