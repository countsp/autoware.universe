# autoware_core

This role installs development/runtime dependencies for Autoware Core.

## Inputs

None.

## Manual Installation

```bash
# Install gdown to download files from CMakeLists.txt
pip3 install gdown
```
